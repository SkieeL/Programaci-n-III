<?php

require_once('Usuario.php');

use Firebase\JWT\JWT as JWT;

class MW {
    public function seteadoCorreoClave($request, $response, $next) {
        $arrayDeParametros = $request->getParsedBody();

        if (!isset($arrayDeParametros["correo"]) && !isset($arrayDeParametros["clave"])) {
            $json = '{ "Error" : "El correo y la clave no se encuentran seteados" }';
            return $response->withJson(json_decode($json), 409);
        }
        else if (!isset($arrayDeParametros["correo"])) {
            $json = '{ "Error" : "El correo no se encuentra seteado" }';
            return $response->withJson(json_decode($json), 409);
        }
        else if (!isset($arrayDeParametros["clave"])) {
            $json = '{ "Error" : "La clave no se encuentra seteada" }';
            return $response->withJson(json_decode($json), 409);
        }

        return $next($request, $response);
    }

    public static function vacioCorreoClave($request, $response, $next) {
        $arrayDeParametros = $request->getParsedBody();

        if ($arrayDeParametros["correo"] == "" && $arrayDeParametros["clave"] == "") {
            $json = '{ "Error" : "El correo y la clave se encuentran vacíos" }';
            return $response->withJson(json_decode($json), 409);
        }
        else if ($arrayDeParametros["correo"] == "") {
            $json = '{ "Error" : "El correo se encuentra vacío" }';
            return $response->withJson(json_decode($json), 409);
        }
        else if ($arrayDeParametros["clave"] == "") {
            $json = '{ "Error" : "La clave se encuentra vacía" }';
            return $response->withJson(json_decode($json), 409);
        }

        return $next($request, $response);
    }

    public function existeCorreoClave($request, $response, $next) {
        $arrayDeParametros = $request->getParsedBody();
        $correo = $arrayDeParametros["correo"];
        $clave = $arrayDeParametros["clave"];

        $usuario = new Usuario("", $correo);
        $resultado = $usuario->traerEsteObj();

        if ($resultado == NULL) {
            $json = '{ "Error" : "El correo no se encuentra registrado" }';
            return $response->withJson(json_decode($json), 409);
        }
        else if ($resultado->clave != $clave) {
            $json = '{ "Error" : "La contraseña es incorrecta" }';
            return $response->withJson(json_decode($json), 409);
        }

        return $next($request, $response);
    }

    public function verificarToken($request, $response, $next) {
        $token = ($request->getHeader("token")[0]);

        try {
            $todo = JWT::decode($token, "1235", ["HS256"]);
        }
        catch(Exception $e) {
            $json = '{ "Error" : "Token inválido" }';
            return $response->withJson(json_decode($json), 409);
        }

        return $next($request, $response);
    }

    public static function verificarPropietario($request, $response, $next) {
        $token = ($request->getHeader("token")[0]);

        $data = JWT::decode($token, "1235", ["HS256"]);

        if ($data->perfil == "propietario") 
            $request = $request->withAttribute('propietario', true);
        else 
            $request = $request->withAttribute('propietario', false);

        return $next($request, $response);
    }

    public function verificarEncargado($request, $response, $next) {
        $token = ($request->getHeader("token")[0]);

        $data = JWT::decode($token, "1235", ["HS256"]);

        if ($data->perfil == "encargado") 
            $request = $request->withAttribute('encargado', true);
        else 
            $request = $request->withAttribute('encargado', false);

        return $next($request, $response);
    }

    public static function verificarEmpleado($request, $response, $next) {
        $token = ($request->getHeader("token")[0]);

        $data = JWT::decode($token, "1235", ["HS256"]);

        if ($data->perfil == "empleado") 
            $request = $request->withAttribute('empleado', true);
        else 
            $request = $request->withAttribute('empleado', false);

        return $next($request, $response);
    }

    public static function validarPropietarioOEncargado($request, $response, $next) {
        $propietario = $request->getAttribute('propietario');
        $encargado = $request->getAttribute('encargado');

        if (!$propietario && !$encargado) {
            $json = '{ "Error" : "Acceso denegado: No es propietario ni encargado" }';
            return $response->withJson(json_decode($json), 409);
        }

        return $next($request, $response);
    }

    public static function validarPropietario($request, $response, $next) {
        $propietario = $request->getAttribute('propietario');

        if (!$propietario) {
            $json = '{ "Error" : "Acceso denegado: No es propietario" }';
            return $response->withJson(json_decode($json), 409);
        }

        return $next($request, $response);
    }
}