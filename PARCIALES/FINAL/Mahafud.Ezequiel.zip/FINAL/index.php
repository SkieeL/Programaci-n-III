<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";
require_once "./clases/Usuario.php";
require_once "./clases/MW.php";
require_once "./clases/Anteojos.php";
require_once "./clases/Venta.php";

use Firebase\JWT\JWT as JWT;

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);

$app->post('[/]', \Anteojos::class . '::cargarAnteojos');

$app->get('/anteojos[/]', \Anteojos::class . '::traerAnteojos');

$app->post('/usuarios[/]', \Usuario::class . '::cargarUsuario');

$app->get('[/]', \Usuario::class . '::traerUsuarios');

$app->post('/login[/]', \Usuario::class . '::crearToken')->add(\MW::class . ':existeCorreoClave')->add(\MW::class . '::vacioCorreoClave')->add(\MW::class . ':seteadoCorreoClave');

$app->get('/login[/]', \Usuario::class . '::verificarToken');

$app->post('/ventas[/]', \Venta::class . '::cargarVenta');

$app->get('/ventas[/]', \Venta::class . '::traerVentas');

$app->delete('[/]', \Anteojos::class . '::borrarAnteojos')->add(\MW::class . '::validarPropietario')->add(\MW::class . '::verificarPropietario')->add(\MW::class . ':verificarToken');

$app->put('[/]', \Anteojos::class . '::modificarAnteojos')->add(\MW::class . '::validarPropietarioOEncargado')->add(\MW::class . ':verificarEncargado')->add(\MW::class . '::verificarPropietario')->add(\MW::class . ':verificarToken');

$app->group('/listados', function () {
    $this->get('/anteojos[/]', \Anteojos::class . '::traerAnteojos');

    $this->get('/anteojos/{id}[/]', \Anteojos::class . '::traerAnteojos');

    $this->get('/ventas[/]', \Venta::class . '::traerVentas');
})->add(\MW::class . '::verificarEmpleado')->add(\MW::class . ':verificarEncargado')->add(\MW::class . '::verificarPropietario')->add(\MW::class . ':verificarToken');

$app->run();

?>