<?php

require_once('AccesoDatos.php');

class Anteojos {
    public $id;
    public $color;
    public $marca;
    public $precio;
    public $aumento;

    public function __construct($id = "", $color = "", $marca = "", $precio = "", $aumento = "") {
        $this->id = $id;
        $this->color = $color;
        $this->marca = $marca;
        $this->precio = $precio;
        $this->aumento = $aumento;
    }

    public function toJson() {
        return '{"id":"'.$this->id.'","color":"'.$this->color.'","marca":"'.$this->marca.'","precio":'.$this->precio.',"aumento":"'.$this->aumento.'"}';
    }

    public function toJsonSinId() {
        return '{"color":"'.$this->color.'","marca":"'.$this->marca.'","precio":'.$this->precio.',"aumento":"'.$this->aumento.'"}';
    }

    public static function cargarAnteojos($request, $response) {
        $arrayDeParametros = $request->getParsedBody();
        $color = $arrayDeParametros["color"];
        $marca = $arrayDeParametros["marca"];
        $precio = $arrayDeParametros["precio"];
        $aumento = $arrayDeParametros["aumento"];
    
        $anteojos = new Anteojos("", $color, $marca, $precio, $aumento);
        $respuesta = $anteojos->Agregar();
    
        if ($respuesta) {
            $json = '{ "status" : "Registro insertado exitosamente" }';
            $codigo = 200;
        }
        else {
            $json = '{ "status" : "Error, no se pudo ingresar el registro en la base de datos" }';
            $codigo = 409;
        }
            
        return $response->withJson(json_decode($json), $codigo);
    }

    public static function traerAnteojos($request, $response, $args) {
        $anteojos = Anteojos::TraerTodoObj();
        $encargado = $request->getAttribute('encargado');
        $propietario = $request->getAttribute('propietario');
        $id = $args['id'];
        $colores = array();
    
        $str = "[ ";
    
        foreach ($anteojos as $obj)  {
            if($str != "[ ")
                $str .= ", ";

            if ($id && $propietario) {
                if ($obj->id == $id) {
                    $str.= $obj->toJson();
                    break;
                }
                else {
                    continue;
                }
            }
    
            if ($encargado) {
                $str .= $obj->toJsonSinId();
                array_push($colores, $obj->color);
            }
            else
                $str .= $obj->toJson();
        }

        if ($encargado) {
            $colores = array_unique($colores);

            if($str != "[ ")
                $str .= ", ";
    
            $str .= '{ "cantidad de colores distintos" : ' . count($colores) . ' }';
        }

        $str.=" ]";
    
        if($str == "[  ]") {
            $str = '{ "status" : "Error" }';
        }
    
        return $response->withJson(json_decode($str), 200);
    }

    public static function borrarAnteojos($request, $response) {
        $id = ($request->getHeader("id")[0]);
    
        $anteojos = new Anteojos($id);
        $respuesta = $anteojos->Borrar();
    
        if ($respuesta) {
            $json = '{ "status" : "Registro eliminado exitosamente" }';
            $codigo = 200;
        } 
        else {
            $json = '{ "status" : "Error, no se pudo eliminar el registro en la base de datos" }';
            $codigo = 409;
        }
            
        return $response->withJson(json_decode($json), $codigo);
    }

    public static function modificarAnteojos($request, $response) {
        $arrayDeParametros = $request->getParsedBody();
        $id = ($request->getHeader("id")[0]);
        $color = ($request->getHeader("color")[0]);
        $marca = ($request->getHeader("marca")[0]);
        $precio = ($request->getHeader("precio")[0]);
        $aumento = ($request->getHeader("aumento")[0]);
    
        $anteojos = new Anteojos($id, $color, $marca, $precio, $aumento);
        $respuesta = $anteojos->Modificar();
    
        if ($respuesta) {
            $json = '{ "status" : "Registro modificado exitosamente" }';
            $codigo = 200;
        }
        else {
            $json = '{ "status" : "Error, no se pudo modificar el registro en la base de datos" }';
            $codigo = 409;
        }
            
        return $response->withJson(json_decode($json), $codigo);
    }

    public function Agregar() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO anteojos (color, marca, precio, aumento) VALUES (:color, :marca, :precio, :aumento)");
        $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
        $consulta->bindValue(':marca', $this->marca, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $this->precio, PDO::PARAM_INT);
        $consulta->bindValue(':aumento', $this->aumento, PDO::PARAM_INT);
        		
        return $consulta->execute();
    }

    public function Borrar() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta = $objetoAccesoDato->RetornarConsulta("DELETE FROM anteojos WHERE id = :id"); 
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->execute();
        
		return $consulta->rowCount();
    }

    public function Modificar() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE anteojos SET color = :color, marca = :marca, precio = :precio, aumento = :aumento WHERE id = :id");
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
        $consulta->bindValue(':marca', $this->marca, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $this->precio, PDO::PARAM_INT);
        $consulta->bindValue(':aumento', $this->aumento, PDO::PARAM_INT);
        		
        return $consulta->execute();
    }

    public function TraerEste() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM anteojos WHERE id = :id");
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->execute();

        return $consulta->fetch(PDO::FETCH_ASSOC);
    }

    public function TraerEsteObj() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM anteojos WHERE id = :id");
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->execute();
        $obj = NULL;

        while($fila = $consulta->fetch()){
            $obj = new Anteojos($fila[0], $fila[1], $fila[2], $fila[3], $fila[4]);
        }

        return $obj;
    }

    public static function TraerTodo() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM anteojos");
        $consulta->execute();

        return $consulta->fetchAll();
    }

    public static function TraerTodoObj() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM anteojos");
        $consulta->execute();
        $arrayObj = array();
        
        while($fila = $consulta->fetch()){
            $obj = new Anteojos($fila[0], $fila[1], $fila[2], $fila[3], $fila[4]);
            array_push($arrayObj, $obj);
        }

        return $arrayObj;
    }
}